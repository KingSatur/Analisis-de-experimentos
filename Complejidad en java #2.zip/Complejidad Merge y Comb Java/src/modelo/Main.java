package modelo;

import java.util.Random;

public class Main {
public static void main(String[] args) {
	//CONSTANTES PARA GENERAR PUNTO DECIMAL
			final double  MS_POR_SEGUNDO = 1000;
			final double  NS_POR_SEGUNDO = 1000000000;
			
		CountingSort a = new CountingSort();
		MergeSort m = new MergeSort();
		CombSort c = new CombSort();
		
		//Se genera un arreglos con 10^8 datos
		int arre []= new int[100000000];
		for(int i = 0; i<arre.length; i++) {
			arre[i] = new Random().nextInt(100);
		}
		//Se genera un arreglos con 10^7 datos
			int arre2 []= new int[10000000];
				
			
		for(int i = 0; i<arre2.length; i++) {
			arre2[i] = new Random().nextInt(100);
				}
		//Se genera un arreglos con 10^6 datos
			int arre3 []= new int[1000000];
				
			
		for(int i = 0; i<arre3.length; i++) {
			arre3[i] = new Random().nextInt(100);
				}
		
		// **************CALCULO DE TIEMPO DEL ALGORTIMO comb SORT*****************
		System.out.println("TEST2: RESULTADOS EN MERGE SORT 10^8");
		//PRUEBA DE C�LCULO MILISEGUNDOS
		for(int i=0;i<50;i++) {
		long inicio_MS = System.currentTimeMillis();
	//	m.mergeSort(arre,arre.length-1,arre[0]);
		long duracion_MS = System.currentTimeMillis()-inicio_MS;
		//PRUEBA DE C�LCULO Nanosegundos
		long inicio_NS = System.nanoTime();
		m.mergeSort(arre,arre.length-1,arre[0]);
		//c.sort(arre);

		long duracion_NS = System.nanoTime()-inicio_NS;
		
		double DURACION_S1 = duracion_MS/MS_POR_SEGUNDO;
		double DURACION_S2 = duracion_NS/NS_POR_SEGUNDO;
		
		System.out.println(i+") "+duracion_NS);
		}
		
		
		//************************************************************
		System.out.println("TEST2: RESULTADOS EN MERGE SORT 10^7");
		//PRUEBA DE C�LCULO MILISEGUNDOS
		for(int i=0;i<50;i++) {
		long inicio_MS = System.currentTimeMillis();
	//	m.mergeSort(arre,arre.length-1,arre[0]);
		long duracion_MS = System.currentTimeMillis()-inicio_MS;
		//PRUEBA DE C�LCULO Nanosegundos
		long inicio_NS = System.nanoTime();
		m.mergeSort(arre2,arre2.length-1,arre2[0]);
		//c.sort(arre2);

		long duracion_NS = System.nanoTime()-inicio_NS;
		
		double DURACION_S1 = duracion_MS/MS_POR_SEGUNDO;
		double DURACION_S2 = duracion_NS/NS_POR_SEGUNDO;
		
		System.out.println(i+") "+duracion_NS);
		}
		//************************************************************
		
		System.out.println("TEST2: RESULTADOS EN MERGE SORT 10^6");
		//PRUEBA DE C�LCULO MILISEGUNDOS
		for(int i=0;i<50;i++) {
		long inicio_MS = System.currentTimeMillis();
	//	m.mergeSort(arre,arre.length-1,arre[0]);
		long duracion_MS = System.currentTimeMillis()-inicio_MS;
		//PRUEBA DE C�LCULO Nanosegundos
		long inicio_NS = System.nanoTime();
		m.mergeSort(arre3,arre3.length-1,arre3[0]);
		//c.sort(arre3);

		long duracion_NS = System.nanoTime()-inicio_NS;
		
		double DURACION_S1 = duracion_MS/MS_POR_SEGUNDO;
		double DURACION_S2 = duracion_NS/NS_POR_SEGUNDO;
		
		System.out.println(i+") "+duracion_NS);
		}
		//************************************************************
	
		

		
		
		

		}

}
